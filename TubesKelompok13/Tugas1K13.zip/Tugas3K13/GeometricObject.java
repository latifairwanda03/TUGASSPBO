/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas3K13;

/**
 *
 * @author akels
 */
public interface GeometricObject {
    double getArea();
    double getPerimeter();
}
